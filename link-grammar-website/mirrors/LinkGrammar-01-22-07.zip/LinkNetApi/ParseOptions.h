/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#pragma once


#include "Linkage.h"


extern "C"
{
	#include "link-includes.h"
}

using namespace System;
namespace ProAI
{ 
	namespace LinkGrammar
	{

	public __gc class ParseOptions : public ProAI::NLP::Framework::IParseOptions, public IDisposable
		{
			public:
				ParseOptions(void);
				ParseOptions(ProAI::NLP::Framework::IParseOptions __gc*);
				~ParseOptions(void);
				void Dispose();
				
				Linkage __gc* CreateLinkage(int k,::Sentence sent){return new Linkage(k,sent,m_opts);}
				Object __gc* Clone(){return NULL;}
				int Parse(::Sentence sent){return ::sentence_parse(sent,m_opts);}	


				__property void set_Verbosity(int verbosity){parse_options_set_verbosity(m_opts,verbosity);}
				__property int  get_Verbosity(){return parse_options_get_verbosity(m_opts);}

				__property void set_LinkageLimit( int linkage_limit){parse_options_set_linkage_limit(m_opts,linkage_limit);}
				__property int  get_LinkageLimit(){return parse_options_get_linkage_limit(m_opts);}

				__property void set_DisjunctCost( int disjunct_cost){parse_options_set_disjunct_cost(m_opts,disjunct_cost);}
				__property int  get_DisjunctCost(){return parse_options_get_disjunct_cost(m_opts);}

				__property void set_MinNullCount( __property int null_count){parse_options_set_min_null_count(m_opts,null_count);}
				__property int  get_MinNullCount(){return parse_options_get_min_null_count(m_opts);}
				
				__property void set_MaxNullCount( int null_count){parse_options_set_max_null_count(m_opts,null_count);}
				__property int  get_MaxNullCount(){return parse_options_get_max_null_count(m_opts);}

				__property void set_NullBlock( int null_block){parse_options_set_null_block(m_opts,null_block);}
				__property int  get_NullBlock(){return parse_options_get_null_block(m_opts);}

				__property void set_ShortLength( int short_length){parse_options_set_short_length(m_opts,short_length);}
				__property int  get_ShortLength(){return parse_options_get_short_length(m_opts);}

				__property void set_IslandsOk( bool islands_ok){parse_options_set_islands_ok(m_opts, islands_ok);}
				__property bool  get_IslandsOk(){return parse_options_get_islands_ok(m_opts)==0?false:true;}

				__property void set_MaxParseTime( int secs){parse_options_set_max_parse_time(m_opts, secs);}
				__property int  get_MaxParseTime(){return parse_options_get_max_parse_time(m_opts);}

				__property void set_MaxMemory( int mem){parse_options_set_max_memory(m_opts,mem);}
				__property int  get_MaxMemory(){return parse_options_get_max_memory(m_opts);}

				__property int  get_TimerExpired(){return parse_options_timer_expired(m_opts);}
				__property void set_TimerExpired(int expired){}
				
				__property int  get_MemoryExhausted(){return parse_options_memory_exhausted(m_opts);}
				__property void set_MemoryExhausted(int exhausted){}
				
				__property int  get_ResourcesExhausted(){return parse_options_resources_exhausted(m_opts);}
				__property void set_ResourcesExhausted(int exhausted){}
				
				__property void set_CostModelType( int cm){parse_options_set_cost_model_type(m_opts,cm);}
				__property int  get_CostModelType(){return parse_options_get_cost_model_type(m_opts);}

				__property void set_ScreenWidth( int val){parse_options_set_screen_width(m_opts,val);}
				__property int  get_ScreenWidth(){return parse_options_get_screen_width(m_opts);}

				__property void set_AllowNull( bool val){parse_options_set_allow_null(m_opts, val);}
				__property bool  get_AllowNull(){return parse_options_get_allow_null(m_opts)==0?false:true;}

				__property bool get_DisplayUnion(){return ::parse_options_get_display_union(m_opts)==0?false:true;}
                __property void set_DisplayUnion(bool display){::parse_options_set_display_union(m_opts,display);}
				
				__property void set_DisplayWalls( bool val){parse_options_set_display_walls(m_opts,val);}
				__property bool  get_DisplayWalls(){return parse_options_get_display_walls(m_opts)==0?false:true;}

				__property void set_AllShortConnectors( bool val){parse_options_set_all_short_connectors(m_opts,val);}
				__property bool  get_AllShortConnectors(){return parse_options_get_all_short_connectors(m_opts)==0?false:true;}

				void ResetResources(){parse_options_reset_resources(m_opts);}

		   protected:
              void Dispose(bool disposing);
				
			private:
				::Parse_Options m_opts;
		};
	}
}