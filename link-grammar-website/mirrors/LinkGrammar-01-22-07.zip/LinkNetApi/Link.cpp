/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/


#include ".\link.h"
#using <mscorlib.dll>
namespace ProAI
{
	namespace LinkGrammar
	{
		Link::Link(int link,::Linkage  linkage)
		{
			
			m_linkage = linkage;
			m_current_link = link;
		}

		Link::~Link(void)
		{
			Dispose(false);
		}
		void
		Link::Dispose()
		{
			GC::SuppressFinalize(this);
			Dispose(true);
		}
		void
		Link::Dispose(bool disposing)
		{
			if(m_linkage!=NULL)::linkage_delete(m_linkage);
		}

		void 
		Link::set_LinkIndex(int index)
		{
			m_current_link = index;
		}
		
		StringCollection __gc*  
		Link::get_DomainNames()
		{
			StringCollection __gc* names = new StringCollection();
			char ** namelist = ::linkage_get_link_domain_names(m_linkage,  m_current_link);
			for(int i=0;i<this->get_NumDomains();i++)
			{
				names->Add(new System::String((*namelist)));
				namelist++;
			}
			return names;
		}
	}
}
