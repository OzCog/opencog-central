/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#pragma once

extern "C"
{
	#include "link-includes.h"
}

#using <System.Xml.dll>

#include "Constituent.h"
#include "Link.h"

using namespace System;
using namespace System::Collections::Generic;
using namespace System::Collections::Specialized;
using namespace System::Xml::Serialization;

namespace ProAI
{ 
	namespace LinkGrammar
	{
		/// <summary>
		/// </Summary>
		[XmlRootAttribute()]
		public __gc class Conjunction : public ProAI::NLP::Framework::IConjunction
		{
		public:
			Conjunction(){}
			Conjunction(int conjunction,::Linkage linkage);
			~Conjunction(void);
		    void Dispose();
			Object __gc* Clone(){return MemberwiseClone();}
			[XmlElementAttribute]
			__property virtual int  get_Numsublinkages(){if(m_linkage!=NULL)return ::linkage_get_num_sublinkages(m_linkage); else return -1;}
		public:
			__property virtual void  set_SublinkageId(int index);
			__property virtual int  get_SublinkageId(){return m_current;}
		public:	
			
            [XmlElementAttribute]
			__property virtual int  get_NumWords(){return ::linkage_get_num_words(m_linkage);}
            
			[XmlElementAttribute]
			__property virtual int  get_NumLinks(){return ::linkage_get_num_links(m_linkage);}
            
			System::String virtual __gc* PrintDiagram();
			System::String virtual __gc* PrintPostscript(int mode);
			System::String virtual __gc* PrintLinksAndDomains();
			System::String virtual __gc* PrintConstituentTree(int mode);
					
			
			__property virtual System::String __gc* get_ViolationName(){return new System::String(::linkage_get_violation_name(m_linkage));}
			__property virtual void set_ViolationName(System::String __gc* name){}

			__property StringCollection virtual __gc*  get_Words();
			__property virtual void  set_Words(StringCollection __gc* words){}

			__property System::String virtual __gc*  get_Word(int w){return new System::String(::linkage_get_word(m_linkage,  w));}
           
			__property int  virtual get_UnusedWordCost(){return ::linkage_unused_word_cost(m_linkage);}
			__property virtual void set_UnusedWordCost(int cost){}
			
			__property int  virtual get_DisjunctCost(){return ::linkage_disjunct_cost(m_linkage);}
			__property virtual void set_DisjunctCost(int cost){}
			
			__property int  virtual get_Cost(){return ::linkage_and_cost(m_linkage);}
			__property virtual void set_Cost(int cost){}
		
			__property int  virtual get_LinkCost(){return linkage_link_cost(m_linkage);}
			__property virtual void set_LinkCost(int cost){}
			
			__property System::Collections::Generic::IList<ProAI::NLP::Framework::ILink __gc*> virtual __gc* get_Links();
			__property virtual void set_Links(System::Collections::Generic::IList<ProAI::NLP::Framework::ILink __gc*> __gc* links){}

			void virtual PostProcess(::PostProcessor post){::linkage_post_process(m_linkage,post);}
			
		
		protected:
			virtual void Dispose(bool disposing);
			::Linkage m_linkage;
            int  m_current;
			bool m_master;
			void  ComputeUnion()
			{
				::linkage_compute_union(m_linkage);
				::linkage_set_current_sublinkage(m_linkage,::linkage_get_num_sublinkages(m_linkage)-1);
			}
	
		};
	}
}