/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/


#include ".\linkage.h"
#using <mscorlib.dll>
namespace ProAI
{
	namespace LinkGrammar
	{
		Linkage::Linkage(int k,::Sentence sent,Parse_Options opts): Conjunction(0,::linkage_create(k,sent,opts))
		{
			
			m_sent = sent;
			m_opts = opts;
			m_linkageId = k;
			m_disjunct_cost = ::sentence_disjunct_cost(m_sent,m_linkageId);
			m_violations = ::sentence_num_violations(m_sent,m_linkageId);
			m_master = true;
			ComputeUnion();
			
		}

		Linkage::~Linkage(void)
		{
			Dispose(false);
		}
		
		void
		Linkage::Dispose()
		{
			GC::SuppressFinalize(this);
			Dispose(true);
		}
		
		void
		Linkage::Dispose(bool disposing)
		{
			Conjunction::Dispose(disposing);
			
		}
		
	    System::Collections::Generic::IList<ProAI::NLP::Framework::IConjunction __gc*> __gc* 
		Linkage::get_Conjunctions()
		{
			System::Collections::Generic::IList<ProAI::NLP::Framework::IConjunction __gc*> __gc* list = new List<ProAI::NLP::Framework::IConjunction __gc*>();
			int num = ::linkage_get_num_sublinkages(m_linkage);
			for(int i=0;i<num-1;i++)
			{
			   list->Add(new Conjunction(i,::linkage_create(m_linkageId,m_sent,m_opts)));
			}
			return list;
		}
        
	}
}
