/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#pragma once

extern "C"
{
	#include "link-includes.h"
}

#using <System.Xml.dll>

#include "Constituent.h"
#include "Conjunction.h"
using namespace System;
using namespace System::Collections::Generic;
using namespace System::Collections::Specialized;
using namespace System::Xml::Serialization;

namespace ProAI
{ 
	namespace LinkGrammar
	{
		[XmlRootAttribute()]
		public __gc class Linkage :  public ProAI::NLP::Framework::ILinkage , public Conjunction, public IDisposable
		{
		public:
			Linkage(){}
			Linkage(int k,::Sentence  sent,::Parse_Options  opts);
			~Linkage(void);
		    
			void Dispose();
			
			__property System::Collections::Generic::IList<ProAI::NLP::Framework::IConjunction __gc*> __gc* get_Conjunctions();
			__property void set_Conjunctions(System::Collections::Generic::IList<ProAI::NLP::Framework::IConjunction __gc*> __gc* list){}
			
			__property int get_LinkageId(){return m_linkageId;}
			__property void set_LinkageId(int id){m_linkageId = id;}
		    __property int get_Violations(){return m_violations;}
            __property void set_Violations(int i){m_violations = i;}  
		    __property int get_DisjunctCost(){return m_disjunct_cost;}   
		    __property void set_DisjunctCost(int i){m_disjunct_cost  = i;}
			__property ProAI::NLP::Framework::IConstituent __gc* get_Constituents(){return new Constituent(m_linkage);}
			__property void set_Constituents(ProAI::NLP::Framework::IConstituent __gc* constituent){}
            
           
		protected:
		  void Dispose(bool disposing);
		  
		  ::Sentence m_sent;
		  ::Parse_Options m_opts;
		  int m_linkageId;
		  int m_violations;
		  int m_disjunct_cost;
            
		
		
		};
	}
}