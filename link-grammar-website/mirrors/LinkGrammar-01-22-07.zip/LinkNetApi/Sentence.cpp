/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/


#include ".\sentence.h"
#using <mscorlib.dll>

using namespace System::Runtime::InteropServices;




namespace ProAI
{ 
	namespace LinkGrammar
	{
		Sentence::Sentence(char __nogc* input_string,::Dictionary dict)
		{	
			Init(input_string,dict,new ParseOptions());	
		}

		Sentence::Sentence(char __nogc* input_string,::Dictionary dict,ParseOptions __gc* opts)
		{
			Init(input_string,dict,opts);

		}
		void Sentence::Init(char __nogc* input_string,::Dictionary dict,ParseOptions __gc* opts)
		{
            m_opts = opts;
			m_dict = dict;
			
			m_sent =  ::sentence_create(input_string,m_dict); 	
			Parse();
			m_sentence = input_string;

			m_length = ::sentence_length(m_sent);
			m_null_count = ::sentence_null_count(m_sent);
			m_linkages = ::sentence_num_linkages_found(m_sent);
		    m_valid = ::sentence_num_valid_linkages(m_sent);
			m_post_processed = ::sentence_num_linkages_post_processed(m_sent);
		}
		Sentence::~Sentence(void)
		{
			Dispose(false);
		}
        
		void 
		Sentence::Dispose()
		{
			GC::SuppressFinalize(this);
			Dispose(true);
		}
		
		void 
		Sentence::Dispose(bool disposing)
		{
			::sentence_delete(m_sent);
		}
		Linkage __gc* 
		Sentence::CreateLinkage(int k,ParseOptions __gc* opts)
		{
            Linkage __gc* linkage = opts->CreateLinkage(k,m_sent);
			
			return linkage;
		}
		
		Linkage __gc* 
		Sentence::CreateLinkage(int k)
		{

			Linkage __gc* linkage = m_opts->CreateLinkage(k,m_sent);
			
			return linkage;
		}
		
		void
		Sentence::set_Input(System::String __gc* input_string)
		{
            char* str1 = (char*)(void*)Marshal::StringToHGlobalAnsi(input_string);
			m_sent =  ::sentence_create(str1,m_dict); 	
			Parse();

			m_sentence = input_string;
			Marshal::FreeHGlobal(str1);
		}
		
		
		System::Collections::Generic::IList<ProAI::NLP::Framework::ILinkage __gc*> __gc*
		Sentence::get_Linkages()
		{
			
			System::Collections::Generic::IList<ProAI::NLP::Framework::ILinkage __gc*> __gc* list = new List<ProAI::NLP::Framework::ILinkage __gc*>;
			int num = ::sentence_num_linkages_found(m_sent);
			for(int i=0;i<num;i++)
			{
			    Linkage __gc* linkage = m_opts->CreateLinkage(i,m_sent);
				list->Add(linkage);
			}
			
			return list;
			
		}
		System::Collections::Generic::IList<ProAI::NLP::Framework::IWordInfo __gc*> __gc*
		Sentence::get_Words()
		{
			System::Collections::Generic::IList<ProAI::NLP::Framework::IWordInfo __gc*> __gc* list = new System::Collections::Generic::List<ProAI::NLP::Framework::IWordInfo __gc*>();
			int num = ::sentence_length(m_sent);
			for(int i=0;i<num;i++)
			{
				list->Add(new ProAI::NLP::Framework::WordInfo(::sentence_get_word(m_sent,i)));
			}
			return list;
		}
		


	}
}