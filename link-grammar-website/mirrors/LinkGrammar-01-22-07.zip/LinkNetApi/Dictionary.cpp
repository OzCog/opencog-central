/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#include ".\dictionary.h"

#using <mscorlib.dll>
using namespace System::Runtime::InteropServices;


namespace ProAI
{
	namespace LinkGrammar
	{
		Dictionary::Dictionary(void)
		{	
			m_dict = ::dictionary_create("4.0.dict", "4.0.knowledge","4.0.constituent-knowledge", "4.0.affix");
		}
		
		Dictionary::Dictionary(System::String __gc* dict_name,System::String __gc* pp_name,System::String __gc* cons_name,System::String __gc* affix_name)
 		{
			char* str1 = (char*)(void*)Marshal::StringToHGlobalAnsi(dict_name);
			char* str2 = (char*)(void*)Marshal::StringToHGlobalAnsi(pp_name);
			char* str3 = (char*)(void*)Marshal::StringToHGlobalAnsi(cons_name);
			char* str4 = (char*)(void*)Marshal::StringToHGlobalAnsi(affix_name);
			m_dict = ::dictionary_create(str1,str2,str3,str4);
			Marshal::FreeHGlobal(str1);
			Marshal::FreeHGlobal(str2);
			Marshal::FreeHGlobal(str3);
			Marshal::FreeHGlobal(str4);
		}
		Dictionary::~Dictionary(void)
		{
			Dispose(false);
		}
		void
		Dictionary::Dispose()
		{
			GC::SuppressFinalize(this);
			Dispose(true);
		}
		void
		Dictionary::Dispose(bool disposing)
		{
           ::dictionary_delete(m_dict);
		}
		Sentence __gc*
		Dictionary::CreateSentence(System::String __gc* input_string)
		{
			char* str = (char*)(void*)Marshal::StringToHGlobalAnsi(input_string);
			Sentence __gc* sent = new Sentence(str,m_dict);
			Marshal::FreeHGlobal(str);
			return sent;
		}

		Sentence __gc* 
		Dictionary::CreateSentence(System::String __gc* input_string,ParseOptions __gc* opts)
		{
			char* str = (char*)(void*)Marshal::StringToHGlobalAnsi(input_string);
			Sentence __gc* sent = new Sentence(str,m_dict,opts);
			Marshal::FreeHGlobal(str);
			return sent;
		}
		Sentence __gc* 
			Dictionary::CreateSentence(System::String __gc* input_string,ProAI::NLP::Framework::IParseOptions __gc* opts)
		{
			char* str = (char*)(void*)Marshal::StringToHGlobalAnsi(input_string);
			Sentence __gc* sent = new Sentence(str,m_dict,new ParseOptions(opts));
			Marshal::FreeHGlobal(str);
			return sent;
		}
	}
}