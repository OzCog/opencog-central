/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#include ".\parseoptions.h"
#using <mscorlib.dll>

using namespace System;
 namespace ProAI
{
	namespace LinkGrammar
	{
		ParseOptions::ParseOptions(void)
		{
			m_opts = ::parse_options_create();
		}
		
		ParseOptions::ParseOptions(ProAI::NLP::Framework::IParseOptions __gc* options)
		{
			m_opts = ::parse_options_create();
			ShortLength = options->ShortLength;
            NullBlock = options->NullBlock;
            MaxNullCount = options->MaxNullCount;
            MinNullCount = options->MinNullCount;
            DisjunctCost = options->DisjunctCost;
            LinkageLimit = options->LinkageLimit;
            MaxParseTime = options->MaxParseTime;
            TimerExpired = options->TimerExpired;
            MaxMemory = options->MaxMemory;
            MemoryExhausted = options->MemoryExhausted;
            ResourcesExhausted = options->ResourcesExhausted;
            CostModelType = options->CostModelType;
            ScreenWidth = options->ScreenWidth;
            Verbosity = options->Verbosity;
            IslandsOk = options->IslandsOk;
            DisplayUnion = options->DisplayUnion;
            DisplayWalls = options->DisplayWalls;
            AllShortConnectors = options->AllShortConnectors;
            AllowNull= options->AllowNull;
		}
        
		ParseOptions::~ParseOptions(void)
		{
			Dispose(false);
		}
		void
		ParseOptions::Dispose()
		{
			GC::SuppressFinalize(this);
			Dispose(true);
		}
		void
		ParseOptions::Dispose(bool disposing)
		{
			::parse_options_delete(m_opts);
		}
	}
}