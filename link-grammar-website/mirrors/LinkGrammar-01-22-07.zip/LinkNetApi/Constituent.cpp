/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#include ".\Constituent.h"

#using <mscorlib.dll>


namespace ProAI
{
	namespace LinkGrammar
	{
		Constituent::Constituent(::Linkage linkage)
		{		
			m_node = ::linkage_constituent_tree(linkage);
		}
		Constituent::Constituent(::CNode __nogc* node)
		{		
			m_node = node;
		}

		Constituent::~Constituent()
		{
			Dispose(false);
		}
		void
		Constituent::Dispose()
		{
			Dispose(true);
			GC::SuppressFinalize(this);
		}
		void
		Constituent::Dispose(bool disposing)
		{
			if(m_node!=NULL)::linkage_free_constituent_tree(m_node);
		}

        IList __gc*
		Constituent::get_Siblings()
		{
			ArrayList __gc* list = new ArrayList();
			::CNode __nogc* node = m_node->next;
			
			while(node!=NULL)
			{	
				list->Add(new Constituent(node));
				node=node->next;
			}
			return list;
		}
	    IList __gc*
		Constituent::get_Children()
		{
			ArrayList __gc* list = new ArrayList();
			::CNode __nogc* node = m_node->child;
			
			while(node!=NULL)
			{	
				list->Add(new Constituent(node));
				node=node->child;
			}
			return list;
		}
		
	}	
}