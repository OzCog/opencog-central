/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#pragma once

extern "C"
{
	#include "link-includes.h"
}

#using <System.Xml.dll>

#include "Constituent.h"

using namespace System;
using namespace System::Collections;
using namespace System::Collections::Specialized;
using namespace System::Xml::Serialization;

namespace ProAI
{ 
	namespace LinkGrammar
	{
		[XmlRootAttribute(ElementName="LinkRoot",IsNullable=false),SerializableAttribute]
		public __gc class Link : public ProAI::NLP::Framework::ILink
		{
		public:
			
			Link(){}
			Link(int link,::Linkage sent);
			~Link(void);
		    void Dispose();
			
			[XmlElementAttribute]
			__property int  get_LinkIndex(){return m_current_link;}
			__property void  set_LinkIndex(int index);
			
		public:		
			Object __gc* Clone(){return MemberwiseClone();}
            [XmlElementAttribute]
			__property int  get_Length(){return ::linkage_get_link_length(m_linkage,m_current_link);}
			//[Obsolete("this method is here only for xml serialization and should not be used.",true)]
			__property void  set_Length(int length){}
			[XmlElementAttribute]
			__property int  get_LeftWord(){return ::linkage_get_link_lword( m_linkage,m_current_link);}
			//[Obsolete("this method is here only for xml serialization and should not be used.",true)]
			__property void  set_LeftWord(int word){}
			[XmlElementAttribute]
			__property int  get_RightWord(){return ::linkage_get_link_rword(m_linkage,m_current_link);}
			//[Obsolete("this method is here only for xml serialization and should not be used.",true)]
			__property void  set_RightWord(int word){}
			[XmlElementAttribute]
			__property System::String __gc* get_Label() {return new System::String(::linkage_get_link_label( m_linkage, m_current_link));}
			//[Obsolete("this method is here only for xml serialization and should not be used.",true)]
			__property void set_Label(System::String __gc* label) {}
			[XmlElementAttribute]
			__property System::String __gc* get_LeftLabel(){return new System::String(::linkage_get_link_llabel(m_linkage, m_current_link));}
			//[Obsolete("this method is here only for xml serialization and should not be used.",true)]
			__property void set_LeftLabel(System::String __gc* label){}
			[XmlElementAttribute]
			__property System::String __gc* get_RightLabel(){return new System::String(::linkage_get_link_rlabel( m_linkage, m_current_link));}
			//[Obsolete("this method is here only for xml serialization and should not be used.",true)]
			__property void set_RightLabel(System::String __gc* label){}
			[XmlElementAttribute]
			__property int      get_NumDomains(){return ::linkage_get_link_num_domains( m_linkage, m_current_link);}
			//[Obsolete("this method is here only for xml serialization and should not be used.",true)]
			__property void      set_NumDomains(int num){}
			[XmlElementAttribute]
			__property StringCollection __gc*  get_DomainNames();
			//[Obsolete("this method is here only for xml serialization and should not be used.",true)]
			__property void  set_DomainNames(StringCollection __gc* names){}
		protected:
			void Dispose(bool disposing);
		private:
			::Linkage m_linkage;
			int m_current_link;
			//int m_sublink;

			int m_length;
			int m_lword;
			int m_rword;
			int m_label;
			int m_llabel;
			int m_rlabel;
			int m_numdomains;
			
		};
	}
}