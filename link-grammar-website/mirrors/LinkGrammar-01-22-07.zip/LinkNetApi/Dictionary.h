/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#pragma once

#include ".\sentence.h"

extern "C"
{
	#include "link-includes.h"
}

#include "ParseOptions.h"

using namespace System;
namespace ProAI
{ 
	namespace LinkGrammar
	{
	public __gc class Dictionary : public IDisposable
		{
		public:
			///<summary>
			///Creates a link grammar dictionary.
			///</summary>
			///<remarks>
			///Uses link grammar default settings.
			///</remarks>
			Dictionary(void);
			///<summary>
			///</summary>
			Dictionary(System::String __gc* dict_name,System::String __gc* pp_name,System::String __gc* cons_name,System::String __gc* affix_name);
			///<summary>
			///</summary>
			~Dictionary(void);
			///<summary>
			///</summary>
			__property int get_MaxCost() {return ::dictionary_get_max_cost(m_dict);}
			///<summary>
			///Creates a sentence using link grammar default options.
			///</summary>
			Sentence __gc* CreateSentence(System::String __gc* input_string);
			///<summary>
			///Creates a sentence using user options.
			///</summary>
			Sentence __gc* CreateSentence(System::String __gc* input_string,ParseOptions __gc* opts);
			///<summary>
			///Creates a sentence using user options.
			///</summary>
			Sentence __gc* CreateSentence(System::String __gc* input_string,ProAI::NLP::Framework::IParseOptions __gc* opts);
			///<summary>
			/// Disposes of the object.
			///</summary>
			void Dispose();
		protected:
			void Dispose(bool Disposing);
		private:
			::Dictionary m_dict;
		};
	}
}