/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/


#include ".\conjunction.h"
#using <mscorlib.dll>
namespace ProAI
{
	namespace LinkGrammar
	{
		
		
		
		Conjunction::Conjunction(int conjunction,::Linkage linkage)
		{
			m_linkage = linkage;
			m_current = conjunction;
			set_SublinkageId(m_current);
			
		}

		Conjunction::~Conjunction(void)
		{
			Dispose(false);
		}
		void
		Conjunction::Dispose()
		{
			GC::SuppressFinalize(this);
			Dispose(true);
		}
		void
		Conjunction::Dispose(bool disposing)
		{
			if(m_linkage!=NULL)::linkage_delete(m_linkage);
		}

		void  
		Conjunction::set_SublinkageId(int index)
		{
			m_current = index; 
			if(m_linkage!=NULL)
			{
			 
		     int result = ::linkage_set_current_sublinkage(m_linkage, index);
			}
		}

		System::String __gc* 
		Conjunction::PrintDiagram()
		{
			if(m_master)
			{
			   ComputeUnion();
			}
			char *str = ::linkage_print_diagram(m_linkage);
			System::String __gc* diagram = new System::String(str);
			::string_delete(str);
			return diagram;
		}

		System::String __gc* 
		Conjunction::PrintPostscript(int mode)
		{
			if(m_master)
			{
			   ComputeUnion();
			}
			char* str = ::linkage_print_postscript( m_linkage, mode);
			System::String __gc* diagram = new System::String(str);
			::string_delete(str);
			return diagram;
		}

		System::String __gc*
		Conjunction::PrintLinksAndDomains()
		{
			if(m_master)
			{
			   ComputeUnion();
			}
			char* str = ::linkage_print_links_and_domains(m_linkage);
			System::String __gc* diagram = new System::String(str);
			::string_delete(str);
			return diagram;
		}

		System::String __gc*
		Conjunction::PrintConstituentTree(int mode)
		{
			char* str = linkage_print_constituent_tree(m_linkage, mode);
			System::String __gc* diagram = new System::String(str);
			::string_delete(str);
			return diagram;
		}
		
		StringCollection __gc*  
		Conjunction::get_Words()
		{
			
			StringCollection  __gc* words = new StringCollection();
			char ** wordlist = ::linkage_get_words(m_linkage);
			for(int i=0;i<this->get_NumWords();i++)
			{
				words->Add(new System::String((*wordlist)));
				wordlist++;
			}
			return words;
		}
		System::Collections::Generic::IList<ProAI::NLP::Framework::ILink __gc*> __gc*
		Conjunction::get_Links()
		{  
			if(m_master)
			{
			   ComputeUnion();
			}
			System::Collections::Generic::List<ProAI::NLP::Framework::ILink __gc*> __gc* list = new List<ProAI::NLP::Framework::ILink __gc*>();
			int num = ::linkage_get_num_links(m_linkage);
			for(int i=0;i<num;i++)
			{
			   list->Add(new Link(i,m_linkage));
			}
			return list;
		}

	}
}
