/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#pragma once

#include "Linkage.h"



using namespace System;
namespace ProAI
{
	namespace LinkGrammar
	{
	public __gc class PostProcessor : public IDisposable
		{
		public:
			PostProcessor(System::String __gc* dict,System::String __gc* name);
			~PostProcessor(void){Dispose(false);}
			void Dispose();
			void PostProcess(Linkage __gc* linkage){linkage->PostProcess(m_post);}
		protected:
			void Dispose(bool disposing);
		private:
			::PostProcessor /*__value*/ m_post;
		};
	}
}