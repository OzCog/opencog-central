/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#include ".\PostProcessor.h"

#using <mscorlib.dll>

using namespace System::Runtime::InteropServices;
namespace ProAI
{
	namespace LinkGrammar
	{
		PostProcessor::PostProcessor(System::String __gc* dict,System::String __gc* name)
		{	
			char* s_dict = (char*)(void*)Marshal::StringToHGlobalAnsi(dict);
			char* s_name = (char*)(void*)Marshal::StringToHGlobalAnsi(name);
			m_post = ::post_process_open(s_dict,s_name);
			Marshal::FreeHGlobal(s_dict);
			Marshal::FreeHGlobal(s_name);
		}
		void
		PostProcessor::Dispose()
		{
			GC::SuppressFinalize(this);
			Dispose(true);
		}
		void
		PostProcessor::Dispose(bool disposing)
		{
			 ::post_process_close(m_post);
		}
	}
}