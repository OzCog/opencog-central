/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#pragma once

extern "C"
{
	#include "link-includes.h"
}

using namespace System;
using namespace System::Collections;
namespace ProAI
{
	namespace LinkGrammar 
	{
		public __gc class Constituent : public ProAI::NLP::Framework::IConstituent
		{
		public:
			Constituent(){}
			Constituent(::Linkage linkage);
			Constituent(::CNode __nogc* node);
			~Constituent(void);
			void Dispose();
			__property int get_Start(){return m_node->start;}
			__property void set_Start(int start){}
			__property int get_End(){return m_node->end;}
			__property void set_End(int end){}
			__property System::String __gc* get_Label(){return new System::String(m_node->label);}
			__property void set_Label(System::String __gc* label){}

			__property ProAI::NLP::Framework::IConstituent __gc* get_Child(){return new Constituent(m_node->child);}
			__property ProAI::NLP::Framework::IConstituent __gc* get_Next(){return new Constituent(m_node->next);}
			__property bool get_IsNull(){return m_node==NULL;}
			__property IList __gc* get_Siblings();
			__property IList __gc* get_Children();
			Object __gc* Clone(){return MemberwiseClone();}
		protected:
		    void Dispose(bool disposing);
		private:
			
			::CNode __nogc* m_node;
		};
	}
}