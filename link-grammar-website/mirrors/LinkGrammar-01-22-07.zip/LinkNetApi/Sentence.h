/********************************************************************************/
/* Copyright (c) 2005                                                           */
/* Leonard Chalk                                                                */
/* All rights reserved                                                          */
/*                                                                              */
/* Use of the link grammar .Net API program is subject to the terms of          */
/* the license set forth in the LICENSE file included with this software,       */ 
/* and also available at http://www.ProAI.net/link/license.html                 */
/* This license allows free redistribution and use in source and binary         */
/* forms, with or without modification, subject to certain conditions.          */
/*                                                                              */
/********************************************************************************/

#pragma once
    
#include "ParseOptions.h"
#include "Linkage.h"

extern "C"
{
	#include "link-includes.h"
}

#using <System.Xml.dll>

using namespace System;
using namespace System::Collections;
using namespace System::Collections::Specialized;
using namespace System::Collections::Generic;
using namespace System::Xml::Serialization;
namespace ProAI
{
	namespace LinkGrammar
	{
	
    [XmlRootAttribute(ElementName="SentenceRoot",IsNullable=false),SerializableAttribute]
	public __gc class Sentence : public ProAI::NLP::Framework::ISentence
		{
			 
		     public:
				Sentence(void){}
				//Uses system default options & Auto parses
				Sentence(char __nogc* input_string,::Dictionary dict);
				//Auto parses sets default options
				Sentence(char __nogc* input_string,::Dictionary dict,ParseOptions __gc* opts);
				
				~Sentence(void);
	            void Dispose();
				virtual Object __gc* Clone(){return NULL;}
				[XmlElementAttribute(IsNullable=false)]
				__property int get_Length(){return m_length;}
				__property void set_Length(int length){m_length = length;}
				 
				[XmlElementAttribute]
				__property int get_NullCount(){return m_null_count;}
				__property void set_NullCount(int count){m_null_count = count;}
                [XmlElementAttribute()]
				__property int get_LinkagesFound(){return m_linkages;}
				__property void set_NLinkagesFound(int num){m_linkages = num;}
				[XmlElementAttribute()]
				__property int get_ValidLinkages(){return m_valid;}
				__property void set_ValidLinkages(int num){m_valid = num;}
				[XmlElementAttribute()]
				__property int get_LinkagesPostProcessed(){return m_post_processed;}
				__property void set_LinkagesPostProcessed(int num){m_post_processed = num;}
                [XmlElementAttribute()]
				__property System::String __gc* get_Input(){return m_sentence;}
				__property void set_Input(System::String __gc* input_string);
				
				__property System::Collections::Generic::IList<ProAI::NLP::Framework::ILinkage __gc*> __gc* get_Linkages();
				__property void set_Linkages(System::Collections::Generic::IList<ProAI::NLP::Framework::ILinkage __gc*> __gc* list){}
				__property System::Collections::Generic::IList<ProAI::NLP::Framework::IWordInfo __gc*> __gc* get_Words();
				__property void set_Words(System::Collections::Generic::IList<ProAI::NLP::Framework::IWordInfo __gc*> __gc* list){}
				
				//Allow changes to Default Options (does not parse changes)
				__property ProAI::NLP::Framework::IParseOptions __gc* get_Options(){return m_opts;}
				//Sets Default Options (does not parse)
				__property void set_Options(ProAI::NLP::Framework::IParseOptions __gc* options){m_opts = new ParseOptions(options);}
                

				
				//Parses using input option (does not save as default)
				void Parse(ParseOptions __gc* opts){opts->Parse(m_sent);}
				//Parses using system default
				void Parse(){m_opts->Parse(m_sent);}
				void Parse(ProAI::NLP::Framework::IParseOptions __gc* options){(new ParseOptions(options))->Parse(m_sent);}
		
				//sets current linkage and uses input options (does not set default)
				Linkage __gc* CreateLinkage(int k,ParseOptions __gc* opts);
				
				//uses default options & set current linkage
				Linkage __gc* CreateLinkage(int k);
				
				__property bool get_IsParsed(){return true;}
				__property void set_IsParsed(bool status){}
				__property bool get_AutoParse(){return true;}
				__property void set_AutoParse(bool status){}
		   
		protected:
               void Dispose(bool disposing);
			private:
				void Init(char __nogc* input_string,::Dictionary dict,ParseOptions __gc* opts);

				::Dictionary  m_dict;
				::Sentence  m_sent;
				ParseOptions __gc* m_opts;
				
				System::String __gc* m_sentence;
				int m_length;
				int m_null_count;
				int m_linkages;
				int m_valid;
				int m_post_processed;
	            

		
		};
	}
}