using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.Text;



namespace ProAI.NLP.Framework
{
    /// <summary>
    /// An english word.
    /// </summary>
    [Serializable]
    public class WordInfo : IWordInfo
    {
        public WordInfo()
        {
        }
        public WordInfo(string word)
        {
            m_word = word;
        }
        public WordInfo(IWordInfo word)
        {
            m_word = word.Word;
        }
        /// <summary>
        /// The word used for analysis.
        /// </summary>
        public virtual string Word
        {
            get
            {
                return m_word;
            }
            set
            {
                m_word = value;
            }
        }
        protected string m_word;

        #region IDisposable Members
        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
        }

        #endregion

        protected virtual void Dispose(bool disposing)
        {
        }

        #region ICloneable Members

        public object Clone()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
