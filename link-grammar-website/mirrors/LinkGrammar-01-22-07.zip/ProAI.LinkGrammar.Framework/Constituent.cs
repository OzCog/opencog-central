using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    [Serializable]
    public class Constituent 
    {
        public Constituent()
        {
        }
        public Constituent(IConstituent constituent)
        {
            if (!constituent.IsNull)
            {
                m_label = constituent.Label;
                m_child = constituent.Child.IsNull ? null : new Constituent(constituent.Child);
                m_next = constituent.Next.IsNull ? null : new Constituent(constituent.Next);
            }
        }

        private string m_label;
        private Constituent m_child;
        private Constituent m_next;
        #region IConstituent Members
        
        public string Label
        {
            get
            {
                return m_label;
            }
            set
            {
                m_label = value;
            }
        }
        
        public Constituent Child
        {
            get { return m_child; }
            set { m_child = value; }
        }

        public Constituent Next
        {
            get { return m_next; }
            set { m_next = value; }
        }

        

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region ICloneable Members

        public object Clone()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
