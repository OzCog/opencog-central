using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.Text;

namespace ProAI.NLP.Framework
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class Linkage : Conjunction
    {
        public Linkage()  : base()
        {
            m_conjunctions = new ArrayList();
        }
        public Linkage(ILinkage linkage) : base(linkage)
        {
            m_conjunctions = new ArrayList();
            m_linkageid = linkage.LinkageId;
            m_violations = linkage.Violations;
            foreach (IConjunction conjunction in linkage.Conjunctions)
            {
                m_conjunctions.Add(new Conjunction(conjunction));
            }
            m_constituents = new Constituent(linkage.Constituents);
        }
        protected int m_violations;
        protected int m_linkageId;
        protected IList m_conjunctions;
        protected Constituent m_constituents;
        
        #region ILinkage Members

        public int LinkageId
        {
            get
            {
                return m_linkageId;
            }
            set
            {
                m_linkageId = value;
            }
        }

        public int Violations
        {
            get
            {
                return m_violations;
            }
            set
            {
                m_violations = value;
            }
        }

       

        public IList Conjunctions
        {
            get
            {
                return m_conjunctions;
            }
            set
            {
                m_conjunctions = value;
            }
        }

      

    

        public Constituent Constituents
        {
            get
            {
                return m_constituents;
            }
            set
            {
                m_constituents = value;
            }
        }

        

        #endregion

        public override object Clone()
        {
            Linkage clone = (Linkage)base.Clone();
            clone.m_linkageId = m_linkageId;
            clone.Violations = m_violations;
            foreach (Conjunction conjunction in m_conjunctions)
            {
                clone.m_conjunctions.Add(conjunction.Clone());
            }
            
                clone.m_constituents = (Constituent)m_constituents.Clone();
            
            return clone;
        }
    }
}
