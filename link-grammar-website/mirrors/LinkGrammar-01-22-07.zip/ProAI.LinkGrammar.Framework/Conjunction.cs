using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    [Serializable]
    public class Conjunction 
    {
        public Conjunction()
        {
            m_links = new ArrayList();
            m_words = new StringCollection();
        }
        public Conjunction(IConjunction conjunction) : this()
        {
            m_linkageid = conjunction.SublinkageId;
            m_unusedWordCost = conjunction.UnusedWordCost;
            m_disjunctCost = conjunction.DisjunctCost;
            m_linkCost = conjunction.LinkCost;
            m_cost = conjunction.Cost;
            m_violationName = conjunction.ViolationName;
            foreach (string word in conjunction.Words)
            {
                m_words.Add(word);
            }
            foreach(ILink link in conjunction.Links)
            {
                m_links.Add(new Link(link));
            }


        }
        protected int m_linkageid;
        protected int m_unusedWordCost;
        protected int m_disjunctCost;
        protected int m_cost;
        protected int m_linkCost;
        protected string m_violationName;
        protected StringCollection m_words;
        protected IList m_links;
     

        

        public int SublinkageId
        {
            get
            {
                return m_linkageid;
            }
            set
            {
                m_linkageid = value;
            }
        }

        public string ViolationName
        {
            get
            {
                return m_violationName;
            }
            set
            {
                m_violationName = value;
            }
        }

        public StringCollection Words
        {
            get
            {
                return m_words;
            }
            set
            {
                m_words = value; 
            }
        }

        public int UnusedWordCost
        {
            get
            {
                return m_unusedWordCost;
            }
            set
            {
                m_unusedWordCost = value;
            }
        }

        public int DisjunctCost
        {
            get
            {
                return m_disjunctCost;
            }
            set
            {
                m_disjunctCost = value;
            }
        }

        public int Cost
        {
            get
            {
               return m_cost;
            }
            set
            {
                m_cost = value;
            }
        }

        public int LinkCost
        {
            get
            {
                return m_linkCost;
            }
            set
            {
                m_linkCost = value;
            }
        }

        public IList Links
        {
            get
            {
                return m_links;
            }
            set
            {
                m_links = value;
            }
        }

        
       

       

        #region IDisposable Members

        public void Dispose()
        {
          
        }

        #endregion

        #region ICloneable Members

        public virtual object Clone()
        {
            Conjunction conjunction = (Conjunction)MemberwiseClone();
            
            conjunction.m_links.Clear();
            foreach (Link link in m_links)
            {
                conjunction.m_links.Add((Link)link.Clone());
            }
            
            return conjunction;
        }

        #endregion
    }
}
