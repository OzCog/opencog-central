using System;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    public interface IConstituent : IDisposable,ICloneable
    {
        IConstituent Child
        {
            get;          
        }
        IConstituent Next
        {
            get;
        }
        bool IsNull
        {
            get;
        }
        string Label
        {
            get;
            set;
        }
    }
}
