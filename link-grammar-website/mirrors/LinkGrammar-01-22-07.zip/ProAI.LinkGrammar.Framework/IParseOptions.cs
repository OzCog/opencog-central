using System;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    /// <summary>
    /// Stores options values for sentense parsing.
    /// </summary>
    public interface IParseOptions : IDisposable,ICloneable
    {
               
                int Verbosity
                {
                    get;
                    set;
                }
				
				int LinkageLimit
                {
                    get;
                    set;
                }
				
				int DisjunctCost
                {
                    get;
                    set;
                }
				
				int MinNullCount
                {
                    get;
                    set;
                }
				
				
				int MaxNullCount
                {
                    get;
                    set;
                }
				
                
				int NullBlock
                {
                    get;
                    set;
                }
				
        
				int ShortLength
                {
                    get;
                    set;
                }
				
                
				 
                bool IslandsOk
                {
                    get;
                    set;
                }
                
                
                int MaxParseTime
                {
                    get;
                    set;
                }
				
                
                int MaxMemory
                {
                    get;
                    set;
                }

                int TimerExpired
                {
                    get;
                    set;
                }
				
				
                int MemoryExhausted
                {
                    get;
                    set;
                }
				
				
                int ResourcesExhausted
                {
                    get;
                    set;
                }
				
				
                int CostModelType
                {
                    get;
                    set;
                }
				

                int ScreenWidth
                {
                    get;
                    set;
                }
				

                
                bool AllowNull{
                    get;
                    set;
                }
				

                 
                bool DisplayUnion
                {
                    get;
                    set;
                }
                
				
                
                bool DisplayWalls
                {
                    get;
                    set;
                }
				
                bool AllShortConnectors
                {
                    get;
                    set;
                }
                
    }
}
