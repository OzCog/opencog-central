using System;
using System.ComponentModel;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.Text;


namespace ProAI.NLP.Framework
{
    
    /// <summary>
    /// A grammatical break down of an english sentence.
    /// </summary>
    [Serializable]
    public class Sentence : IDisposable,ICloneable
    {
        /// <summary>
        /// Used for serialization/deserialization
        /// </summary>
        public Sentence()
        {
            m_linkages = new ArrayList();
            m_words = new ArrayList(); 
        }
        public Sentence(ISentence sentence) : this()
        {
            Copy(sentence);

        }
        private void Copy(ISentence sentence)
        {
            m_sentence = sentence.Input;
            m_null_count = sentence.NullCount;
            m_valid = sentence.ValidLinkages;
            m_post_processed = sentence.LinkagesPostProcessed;
            m_parsed = sentence.IsParsed;
           
            m_linkages.Clear();
            m_words.Clear();
            foreach (ILinkage linkage in sentence.Linkages)
            {
                m_linkages.Add(new Linkage(linkage));
            }
            foreach (IWordInfo word in sentence.Words)
            {
                m_words.Add(new WordInfo(word));
            }
        }
        /// <summary>
        /// The number of null links that were used in parsing the sentense.
        /// </summary>
        public virtual int NullCount
        {
            get
            {
                return m_null_count;
            }
            set
            {
                m_null_count = value;
            }
        }
        /// <summary>
        /// the number that had no post-processing violations.
        /// </summary>
        public virtual int ValidLinkages
        {
            get
            {
                return m_valid;
            }
            set
            {
                m_valid = value;
            }
        }
        /// <summary>
        /// The number of linkages that were actually post-processed. 
        /// </summary>
        /// <remarks>
        /// May be less than the number found because of the limit option.
        /// </remarks>
        public virtual int LinkagesPostProcessed
        {
            get
            {
                return m_post_processed;
            }
            set
            {
                m_post_processed = value;
            }
        }
        /// <summary>
        /// The input sentense to be parsed.
        /// </summary>
        public virtual string Input
        {
            get
            {
                return m_sentence;
            }
            set
            {
                m_sentence = value;
                m_parsed = false;
                  
            }
        }
      
        public virtual bool IsParsed
        {
            get
            {
                return m_parsed;
            }
            set
            {
                m_parsed = value;
            }
        }
        /// <summary>
        /// The options to use parsing the sentence.
        /// </summary>
        public virtual ParseOptions Options
        {
            get
            {
                return m_opts;
            }
            set
            {
                m_opts = value;
            }
        }
        /// <summary>
        /// The linkages found during the last parse.
        /// </summary>
        public virtual IList Linkages
        {
            get
            {
                return m_linkages;
            }
            set
            {
                m_linkages = value;
            }
        }      
        /// <summary>
        /// A sequential list of the words in the sentence.
        /// </summary>
        public virtual IList Words
        {
            get
            {
                return m_words;
            }
            set
            {
                m_words = value;
            }
        } 
        
        #region IDisposable Members

        public void Dispose()
        {
            Dispose(true);
        }

        #endregion
        
        #region ICloneable Members

        public virtual object Clone()
        {
            Sentence sent = (Sentence)MemberwiseClone();
            sent.m_opts = (ParseOptions)m_opts.Clone();
            foreach (Linkage linkage in m_linkages)
            {
                sent.m_linkages.Add((Linkage)linkage.Clone());
            }    
            foreach (WordInfo word in m_words)
            {
                sent.m_words.Add((WordInfo)word.Clone());
            }
            return sent;
        }
        

        #endregion

        
        protected ParseOptions m_opts;
        protected IList m_words;
        protected IList m_linkages;
	    protected string m_sentence;
		protected int m_null_count;
		protected int m_valid;
	    protected int m_post_processed;
        protected bool m_parsed;
        

        protected virtual void Dispose(bool disposing)
        {
        }

      
    }
}
