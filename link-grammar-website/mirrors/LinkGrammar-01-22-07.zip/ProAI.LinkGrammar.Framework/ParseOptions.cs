using System;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.Text;
using System.Security.Permissions;

namespace ProAI.NLP.Framework
{
    /// <summary>
    /// Contains the options uses for parsing a sentense.
    /// </summary>
    [Serializable]
    public class ParseOptions : IParseOptions, ISerializable
    {
        
        
        public ParseOptions()
        {
            
        }
        
        public ParseOptions(IParseOptions options)
        {
             
             m_shortLength = options.ShortLength;
             m_nullBlock = options.NullBlock;
             m_maxNullCount = options.MaxNullCount;
             m_minNullCount = options.MinNullCount;
             m_disjunctCost = options.DisjunctCost;
             m_linkLimit = options.LinkageLimit;
             m_maxParseTime = options.MaxParseTime;
             m_timerExpired = options.TimerExpired;
             m_maxMemory = options.MaxMemory;
             m_memoryExhausted = options.MemoryExhausted;
             m_resourcesExhausted = options.ResourcesExhausted;
             m_costModelType = options.CostModelType;
             m_screenWidth = options.ScreenWidth;
             m_verbosity = options.Verbosity;
             m_islandOk = options.IslandsOk;
             m_displayUnion = options.DisplayUnion;
             m_displayWalls = options.DisplayWalls;
             m_shortConnectors = options.AllShortConnectors;
             m_allowNull= options.AllowNull;
        }
        public ParseOptions(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }
            m_shortLength = info.GetInt32("ShortLength");
            m_nullBlock = info.GetInt32("NullBlock");
            m_maxNullCount = info.GetInt32("MaxNullCount");
            m_minNullCount = info.GetInt32("MinNullCount");
            m_disjunctCost = info.GetInt32("DisjunctCost");
            m_linkLimit = info.GetInt32("LinkageLimit");
            m_maxParseTime = info.GetInt32("MaxParseTime");
            m_timerExpired = info.GetInt32("TimerExpired");
            m_maxMemory = info.GetInt32("MaxMemory");
            m_memoryExhausted = info.GetInt32("MemoryExhausted");
            m_resourcesExhausted = info.GetInt32("ResourcesExhausted");
            m_costModelType = info.GetInt32("CostModelType");
            m_screenWidth = info.GetInt32("ScreenWidth");
            m_verbosity = info.GetInt32("Verbosity");
            m_islandOk = info.GetBoolean("IslandsOk");
            m_displayUnion = info.GetBoolean("DisplayUnion");
            m_displayWalls = info.GetBoolean("DisplayWalls");
            m_shortConnectors = info.GetBoolean("AllShortConnectors");
            m_allowNull = info.GetBoolean("AllowNull");
            
        }

        

        #region ICloneable Members

        public object Clone()
        {
            return MemberwiseClone();
        }

        #endregion

        #region IParseOptions Members

        public int Verbosity
        {
            get
            {
                return m_verbosity;
            }
            set
            {
                m_verbosity = value;
            }
        }

        public int LinkageLimit
        {
            get
            {
                return m_linkLimit; 
            }
            set
            {
                m_linkLimit = value;
            }
        }

        public int DisjunctCost
        {
            get
            {
                return m_disjunctCost;
            }
            set
            {
                m_disjunctCost = value;
            }
        }

        public int MinNullCount
        {
            get
            {
                return m_minNullCount;
            }
            set
            {
                m_minNullCount = value;
            }
        }

        public int MaxNullCount
        {
            get
            {
                return m_maxNullCount;
            }
            set
            {
                m_maxNullCount = value;
            }
        }

        public int NullBlock
        {
            get
            {
                return m_nullBlock;
            }
            set
            {
                m_nullBlock = value;
            }
        }

        public int ShortLength
        {
            get
            {
                return m_shortLength;
            }
            set
            {
                m_shortLength = value;
            }
        }

        public bool IslandsOk
        {
            get
            {
                return m_islandOk;
            }
            set
            {
                m_islandOk = value;
            }
        }

        public int MaxParseTime
        {
            get
            {
                return m_maxParseTime;
            }
            set
            {
                m_maxParseTime = value;   
            }
        }

        public int MaxMemory
        {
            get
            {
                return m_maxMemory;
            }
            set
            {
                m_maxMemory = value;
            }
        }
        
        public int TimerExpired
        {
            get
            {
                return m_timerExpired;
            }
            set
            {
                m_timerExpired = value;
            }
        }

        public int MemoryExhausted
        {
            get
            {
                return m_memoryExhausted;
            }
            set
            {
                m_memoryExhausted = value;
            }
        }

        public int ResourcesExhausted
        {
            get
            {
                return m_resourcesExhausted;
            }
            set
            {
                m_resourcesExhausted = value;
            }
        }

        public int CostModelType
        {
            get
            {
                return m_costModelType;
            }
            set
            {
                m_costModelType = value;
            }
        }

        public int ScreenWidth
        {
            get
            {
                return m_screenWidth;
            }
            set
            {
                m_screenWidth = value;
            }
        }

        public bool AllowNull
        {
            get
            {
                return m_allowNull;
            }
            set
            {
                m_allowNull = value;
            }
        }

        public bool DisplayUnion
        {
            get
            {
                return m_displayUnion;
            }
            set
            {
                m_displayUnion = value;
            }
        }

        public bool DisplayWalls
        {
            get
            {
                return m_displayWalls;
            }
            set
            {
                m_displayWalls = value;
            }
        }

        public bool AllShortConnectors
        {
            get
            {
                return m_shortConnectors;
            }
            set
            {
                m_shortConnectors = value;
            }
        }

        #endregion

        private int m_shortLength;
        private int m_nullBlock;
        private int m_maxNullCount;
        private int m_minNullCount;
        private int m_disjunctCost;
        private int m_linkLimit;
        private int m_maxParseTime;
        private int m_timerExpired;
        private int m_maxMemory;
        private int m_memoryExhausted;
        private int m_resourcesExhausted;
        private int m_costModelType;
        private int m_screenWidth;
        private int m_verbosity;
        private bool m_islandOk;
        private bool m_displayUnion;
        private bool m_displayWalls;
        private bool m_shortConnectors;
        private bool m_allowNull;

        #region ISerializable Members

        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }
            info.AddValue("ShortLength", m_shortLength);
            info.AddValue("NullBlock",m_nullBlock);
            info.AddValue("MaxNullCount",m_maxNullCount);
            info.AddValue("MinNullCount",m_minNullCount);
            info.AddValue("DisjunctCost",m_disjunctCost);
            info.AddValue("LinkageLimit",m_linkLimit);
            info.AddValue("MaxParseTime",m_maxParseTime);
            info.AddValue("TimerExpired",m_timerExpired);
            info.AddValue("MaxMemory",m_maxMemory);
            info.AddValue("MemoryExhausted",m_memoryExhausted);
            info.AddValue("ResourcesExhausted",m_resourcesExhausted);
            info.AddValue("CostModelType",m_costModelType);
            info.AddValue("ScreenWidth",m_screenWidth);
            info.AddValue("Verbosity",m_verbosity);
            info.AddValue("IslandsOk",m_islandOk);
            info.AddValue("DisplayUnion",m_displayUnion);
            info.AddValue("DisplayWalls",m_displayWalls);
            info.AddValue("AllShortConnectors",m_shortConnectors);
            info.AddValue("AllowNull",m_allowNull);
        }

        #endregion





        #region IDisposable Members

        public void Dispose()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
