using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    public interface ILink : IDisposable,ICloneable
    {
        
			int  LinkIndex
            { 
                get;
                set;
            }
			int  Length
            {
                get;
                set;
            }
			
			
			
			int LeftWord
            {
                get;
                set;
            }
			
			
			int  RightWord
            {
                get;
                set;
            }
			
			string Label
            {
                get;
                set;
            }
			
			string LeftLabel
            {
                get;
                set;
            }

        string RightLabel
        {
            get;
            set;
        }

        int NumDomains
        {
            get;
            set;
        }

        StringCollection DomainNames
        {
            get;
            set;
        }
			
    }
}
