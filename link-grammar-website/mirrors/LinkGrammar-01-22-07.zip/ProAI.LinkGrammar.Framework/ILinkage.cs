using System;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    /// <summary>
    /// 
    /// </summary>
    public interface ILinkage : IConjunction
    {
        int LinkageId
        {
            get;
            set;
        }


        int Violations
        {
            get;
            set;
        }

        
        IList<IConjunction> Conjunctions
        {
            get;
            set;
        }

        IConstituent Constituents
        {
            get;
            set;
        } 
    }
}
