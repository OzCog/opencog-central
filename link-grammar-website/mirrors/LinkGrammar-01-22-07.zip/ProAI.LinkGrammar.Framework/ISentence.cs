using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    /// <summary>
    /// A grammatical break down of an english sentence.
    /// </summary>
    public interface ISentence : IDisposable, ICloneable
    {
        
        /// <summary>
        /// The number of null links that were used in parsing the sentense.
        /// </summary>
        int NullCount
        {
            get;
            set;
        }
        /// <summary>
        /// the number that had no post-processing violations.
        /// </summary>
        int ValidLinkages
        {
            get;
            set;
        }
        /// <summary>
        /// The number of linkages that were actually post-processed. 
        /// </summary>
        /// <remarks>
        /// May be less than the number found because of the limit option.
        /// </remarks>
        int LinkagesPostProcessed
        {
            get;
            set;
        }
        /// <summary>
        /// The input sentense to be parsed.
        /// </summary>
        string Input
        {
            get;
            set;
        }
        /// <summary>
        /// The options to use parsing the sentence.
        /// </summary>
        IParseOptions Options
        {
            get;
            set;
        }
        
        /// <summary>
        /// The linkages found during the last parse.
        /// </summary>
        IList<ILinkage> Linkages
        {
            get;
            set;
        }
        /// <summary>
        /// A sequential list of the words in the sentence.
        /// </summary>
        IList<IWordInfo> Words
        {
            get;
            set;
        }
         
        /// <summary>
        /// Weather or not the current input has been parsed.
        /// </summary>
        bool IsParsed
        {
            get;
            set;
        }
        /// <summary>
        /// Weather to parse on change of input sentence.
        /// </summary>
        bool AutoParse
        {
            get;
            set;
        }
          
    }
}
