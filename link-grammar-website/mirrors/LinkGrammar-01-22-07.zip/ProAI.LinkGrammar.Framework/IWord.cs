using System;
using System.Collections.Generic;
using System.Text;




namespace ProAI.NLP.Framework
{
    /// <summary>
    /// An english word.
    /// </summary>
    public interface IWordInfo : IDisposable,ICloneable
    {
         string Word
        {
            get;
            set;
        }
    }

   
}
