using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    public interface IConjunction : IDisposable, ICloneable
    {



        int SublinkageId
        {
            get;
            set;
        }
		
		
            
		string PrintDiagram();
		string PrintPostscript(int mode);
		string PrintLinksAndDomains();
		string PrintConstituentTree(int mode);
				
		
		string ViolationName
        {
           get;
           set;
        }

		StringCollection Words
        {
            get;
            set;
        }
		
		int  UnusedWordCost
        {
            get;
            set;
        }
		
		int  DisjunctCost
        {
            get;
            set;
        }
		
		int  Cost
        {
            get;
            set;
        }
		
		int  LinkCost
        {
            get;
            set;
        }
		
        IList<ILink> Links
        {
            get;
            set;
        }
		
		
		
			
            
           
		
    }
}
