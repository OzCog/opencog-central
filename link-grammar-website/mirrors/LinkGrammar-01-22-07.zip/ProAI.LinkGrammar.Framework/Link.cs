using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;

namespace ProAI.NLP.Framework
{
    [Serializable]
    public class Link 
    {
        #region IDisposable Members

        public Link()
        {
            m_domains = new StringCollection();
        }
        public Link(ILink link) :this()
        {
            m_current_link = link.LinkIndex;
            m_length = link.Length;
            m_lword = link.LeftWord;
            m_rword = link.RightWord;
            m_label = link.Label;
            m_llabel = link.LeftLabel;
            m_rlabel = link.RightLabel;
            m_numdomains = link.NumDomains;
            foreach (string domain in link.DomainNames)
            {
                m_domains.Add(domain);
            }
        }

        public virtual  void Dispose()
        {
            
        }

        #endregion

        #region ICloneable Members

        public virtual object Clone()
        {
            return MemberwiseClone();
        }

        #endregion

        #region ILink Members

        public virtual int LinkIndex
        {
            get
            {
                return m_current_link;
            }
            set
            {
                m_current_link = value;
            }
        }

        public virtual int Length
        {
            get
            {
                return m_length;
            }
            set
            {
                m_length = value;
            }
        }

        public virtual int LeftWord
        {
            get
            {
                return m_lword;
            }
            set
            {
                m_lword = value;
            }
        }

        public virtual int RightWord
        {
            get
            {
                return m_rword;
            }
            set
            {
                m_rword = value;
            }
        }

        public virtual string Label
        {
            get
            {
                return m_label;
            }
            set
            {
                m_label = value;
            }
        }

        public virtual string LeftLabel
        {
            get
            {
                return m_llabel;
            }
            set
            {
                m_llabel = value;
            }
        }

        public virtual string RightLabel
        {
            get
            {
                return m_rlabel;
            }
            set
            {
                m_rlabel = value;
            }
        }

        public virtual int NumDomains
        {
            get
            {
                return m_numdomains;
            }
            set
            {
                m_numdomains = value;
            }
        }

        public virtual StringCollection DomainNames
        {
            get
            {
                return m_domains;
            }
            set
            {
                m_domains = value;
            }
        }

        #endregion

        int m_current_link;
        int m_length;
        int m_lword;
        int m_rword;
        string m_label;
        string m_llabel;
        string m_rlabel;
        int m_numdomains;
        StringCollection m_domains;
    }
}
