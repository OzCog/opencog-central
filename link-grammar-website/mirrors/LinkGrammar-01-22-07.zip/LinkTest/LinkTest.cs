using System;
using System.Collections;
//using ProAI.LinkGrammar;
using ProAI.NLP.Framework;
namespace LinkTest
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Test
	{
		/// <summary>
		/// This is a simple example of the API capibilities
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			ProAI.LinkGrammar.Dictionary dict = new ProAI.LinkGrammar.Dictionary();
			{
				Console.WriteLine();
				Console.Write("Input a sentence to evaluate or hit Enter to exit: ");
                ProAI.LinkGrammar.ParseOptions opts = new ProAI.LinkGrammar.ParseOptions();
                opts.DisplayUnion = true;
                opts.MaxNullCount=100;
                
				String input = Console.ReadLine();
				while(input!="")
				{

                    ProAI.LinkGrammar.Sentence sent = dict.CreateSentence(input, opts);
					{
						 foreach(ILinkage linkage in sent.Linkages)
						{	
							Console.WriteLine();
							Console.WriteLine("Linkage # "+linkage.LinkageId.ToString()+"'s Constituent Structure:");
							Console.WriteLine();
							Console.WriteLine(linkage.PrintConstituentTree(2));
							PrintConstituentTree(linkage.Constituents);
							Console.WriteLine();
                            Console.WriteLine("Linkage # " + linkage.LinkageId.ToString() + "'s Master Linkage:" + linkage.SublinkageId.ToString());
                            Console.WriteLine(linkage.PrintDiagram());
                            Console.WriteLine();
                            Console.WriteLine("Linkage # " + linkage.LinkageId.ToString() + ", Master Linkage's Links:");
                            Console.WriteLine();
                            foreach (ILink link in linkage.Links)
                            {
                                Console.WriteLine(sent.Words[link.LeftWord].Word.PadRight(10) + "\t" + link.Label + "\t" + sent.Words[link.RightWord].Word);

                            }
                            Console.WriteLine();
                            Console.WriteLine("Conjunction Linkages:");
                            foreach (IConjunction conjunction in linkage.Conjunctions)
                            {
                                Console.WriteLine("Conjunction # " + conjunction.SublinkageId.ToString());
                                Console.WriteLine(conjunction.PrintDiagram());
                                Console.WriteLine();
                                foreach (ILink link in conjunction.Links)
                                {
                                    Console.WriteLine(sent.Words[link.LeftWord].Word.PadRight(10) + "\t" + link.Label + "\t" + sent.Words[link.RightWord].Word);

                                }
                                Console.WriteLine();
                            }
						}
					}
					Console.Write("Input a sentence to evaluate or hit Enter to exit: ");
					input = Console.ReadLine();
				}
			}  
		}
		
		static void PrintConstituentTree(IConstituent node)
		{
            if (!node.IsNull)
            {       
                IConstituent child = node.Child;   
                if (!child.IsNull)
                {
                    Console.Write("[" + node.Label + " ");
                    PrintConstituentTree(child);
                    Console.Write(node.Label + "] ");
                }
                else  Console.Write(node.Label + " ");           
            }
            IConstituent next = node.Next;
            if (!next.IsNull)
            {
                PrintConstituentTree(next);
            }
        }
	}
}
