#pragma once


#include "Api-linkage.h"

extern "C"
{
  #include "link-includes.h"
}

namespace LinkApi
{
class ParseOptions
{
public:
	ParseOptions(void);
	~ParseOptions(void);

	Linkage * CreateLinkage(int k,::Sentence sent){return new Linkage(k,sent,m_opts);}
	int Parse(::Sentence sent){return sentence_parse(sent,m_opts);}

	void set_verbosity(int verbosity){parse_options_set_verbosity(m_opts,verbosity);}
	int  get_verbosity(){return parse_options_get_verbosity(m_opts);}

	void set_linkage_limit(int linkage_limit){parse_options_set_linkage_limit(m_opts,linkage_limit);}
	int  get_linkage_limit(){return parse_options_get_linkage_limit(m_opts);}

	void set_disjunct_cost(int disjunct_cost){parse_options_set_disjunct_cost(m_opts,disjunct_cost);}
	int  get_disjunct_cost(){return parse_options_get_disjunct_cost(m_opts);}

	void set_min_null_count( int null_count){parse_options_set_min_null_count(m_opts,null_count);}
	int  get_min_null_count(){return parse_options_get_min_null_count(m_opts);}
	void set_max_null_count(int null_count){parse_options_set_max_null_count(m_opts,null_count);}
	int  get_max_null_count(){return parse_options_get_max_null_count(m_opts);}

	void set_null_block(int null_block){parse_options_set_null_block(m_opts,null_block);}
	int  get_null_block(){return parse_options_get_null_block(m_opts);}

	void set_short_length(int short_length){parse_options_set_short_length(m_opts,short_length);}
	int  get_short_length(){return parse_options_get_short_length(m_opts);}

	void set_islands_ok(int islands_ok){parse_options_set_islands_ok(m_opts, islands_ok);}
	int  get_islands_ok(){return parse_options_get_islands_ok(m_opts);}

	void set_max_parse_time(int secs){parse_options_set_max_parse_time(m_opts, secs);}
	int  get_max_parse_time(){return parse_options_get_max_parse_time(m_opts);}

	void set_max_memory(int mem){parse_options_set_max_memory(m_opts,mem);}
	int  get_max_memory(){return parse_options_get_max_memory(m_opts);}

	int  timer_expired(){return parse_options_timer_expired(m_opts);}
	int  memory_exhausted(){return parse_options_memory_exhausted(m_opts);}
	int  resources_exhausted(){return parse_options_resources_exhausted(m_opts);}
	void reset_resources(){parse_options_reset_resources(m_opts);}

	void set_cost_model_type(int cm){parse_options_set_cost_model_type(m_opts, cm);}
	int  get_cost_model_type(){return parse_options_get_cost_model_type(m_opts);}

	void set_screen_width(int val){parse_options_set_screen_width(m_opts,val);}
	int  get_screen_width(){return parse_options_get_screen_width(m_opts);}

	void set_allow_null(int val){parse_options_set_allow_null(m_opts, val);}
	int  get_allow_null(){return parse_options_get_allow_null(m_opts);}

	void set_display_walls(int val){parse_options_set_display_walls(m_opts,val);}
	int  get_display_walls(){return parse_options_get_display_walls(m_opts);}

	void set_all_short_connectors(int val){parse_options_set_all_short_connectors(m_opts,val);}
	int  get_all_short_connectors(){return parse_options_get_all_short_connectors(m_opts);}

private:
	::Parse_Options m_opts;
};
}
