#pragma once

#include "Api-linkage.h"
#include "Api-parseOptions.h"

extern "C"
{
  #include "link-includes.h"
}

namespace LinkApi
{
class Sentence
{
public:
	Sentence(char * input_string,::Dictionary dict);
	~Sentence(void);
	Linkage * CreateLinkage(int k,ParseOptions * opts){return opts->CreateLinkage(k,m_sent);}
	
	int Parse(ParseOptions* opts){return opts->Parse(m_sent);}
	
	int length(){return sentence_length(m_sent);}

	char * get_word(int w){return sentence_get_word(m_sent, w);}

	int null_count(){return sentence_null_count(m_sent);}

	int num_linkages_found(){return sentence_num_linkages_found(m_sent);}
	int num_valid_linkages(){return sentence_num_valid_linkages(m_sent);}
	int num_linkages_post_processed(){return sentence_num_linkages_post_processed(m_sent);}

	int num_violations(int i){return sentence_num_violations(m_sent,i);}

	int disjunct_cost(int i){return sentence_disjunct_cost(m_sent,i);}

private:
	::Sentence m_sent;
};
}
