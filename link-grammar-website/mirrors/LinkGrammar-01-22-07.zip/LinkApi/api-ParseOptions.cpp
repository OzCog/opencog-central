#include "StdAfx.h"
#include ".\api-parseoptions.h"

namespace LinkApi
{
	ParseOptions::ParseOptions(void)
	{
		m_opts = ::parse_options_create();
	}

	ParseOptions::~ParseOptions(void)
	{
		::parse_options_delete(m_opts);
	}
}
