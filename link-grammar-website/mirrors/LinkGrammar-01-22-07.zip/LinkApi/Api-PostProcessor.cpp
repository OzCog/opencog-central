#include "StdAfx.h"
#include ".\api-postprocessor.h"

namespace LinkApi
{
	PostProcessor::PostProcessor(char* dict,char * name)
	{
		m_post = ::post_process_open(dict,name);
	}

	PostProcessor::~PostProcessor(void)
	{
		::post_process_close(m_post);
	}
}