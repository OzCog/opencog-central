#pragma once

#include "api-linkage.h"

extern "C"
{
  #include "link-includes.h"
}

namespace LinkApi
{
	class PostProcessor
	{
	public:
		PostProcessor(char* dict,char* name);
		~PostProcessor(void);
		void PostProcess(Linkage* linkage){linkage->PostProcess(m_post);}

	private:
		::PostProcessor m_post;
	};
}