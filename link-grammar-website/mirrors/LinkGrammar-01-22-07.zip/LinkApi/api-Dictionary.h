#pragma once

#include "api-sentence.h"

extern "C"
{
  #include "link-includes.h"
}

namespace LinkApi
{
class Dictionary
{
public:
	Dictionary(void);
	~Dictionary(void);
	int MaxCost(){return ::dictionary_get_max_cost(m_dict);}
	Sentence * CreateSentence(char * input_string);
private:
	::Dictionary m_dict;
};
}
