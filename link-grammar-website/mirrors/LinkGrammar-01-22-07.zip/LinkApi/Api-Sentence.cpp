#include "StdAfx.h"
#include ".\api-sentence.h"


namespace LinkApi
{
	Sentence::Sentence(char * input_string,::Dictionary dict)
	{
		m_sent = ::sentence_create(input_string,dict);
	}

	Sentence::~Sentence(void)
	{
		::sentence_delete(m_sent);
	}
}