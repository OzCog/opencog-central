#pragma once

#include "Api-constituent.h"


extern "C"
{
  #include "link-includes.h"
}


namespace LinkApi
{
class Linkage
{

public:
	Linkage(int k,::Sentence sent,::Parse_Options opts);
	~Linkage(void);
	
	int  get_num_sublinkages(){return linkage_get_num_sublinkages(m_linkage);}

	int  set_current_sublinkage(int index){return linkage_set_current_sublinkage(m_linkage,index);}

	int  compute_union(){return linkage_compute_union(m_linkage);}

	int  get_num_words(){return linkage_get_num_words(m_linkage);}

	int  get_num_links(){return linkage_get_num_links(m_linkage);}

	int  get_link_length(int index){return linkage_get_link_length(m_linkage, index);}
	int  get_link_lword(int index){return linkage_get_link_lword(m_linkage, index);}
	int  get_link_rword(int index){return linkage_get_link_rword(m_linkage, index);}

	char *  print_diagram(){return linkage_print_diagram(m_linkage);}
	char *  print_postscript(int mode){return linkage_print_postscript(m_linkage, mode);}
	char *  print_links_and_domains(){return linkage_print_links_and_domains(m_linkage);}

	char *  get_link_label(int index){return linkage_get_link_label(m_linkage, index);}
	char *  get_link_llabel(int index){return linkage_get_link_llabel(m_linkage, index);}
	char *  get_link_rlabel(int index){return linkage_get_link_rlabel(m_linkage, index);}

	int      get_link_num_domains(int index){return linkage_get_link_num_domains(m_linkage, index);}
	char **  get_link_domain_names(int index){return linkage_get_link_domain_names(m_linkage, index);}
	char *   get_violation_name(){return linkage_get_violation_name(m_linkage);}

	char **  get_words(){return linkage_get_words(m_linkage);}
	char *   get_word(int w){return linkage_get_word(m_linkage, w);}

	int  unused_word_cost(){return linkage_unused_word_cost(m_linkage);}
	int  disjunct_cost(){return linkage_disjunct_cost(m_linkage);}
	int  cost(){return linkage_and_cost(m_linkage);}
	int  link_cost(){return linkage_link_cost(m_linkage);}

	Constituent* CreateConstituent(){return new Constituent(m_linkage);}
	char* print_constituent_tree(int mode){return ::linkage_print_constituent_tree(m_linkage, mode);}
	void  PostProcess(::PostProcessor post){::linkage_post_process(m_linkage, post);}
private:
	::Linkage m_linkage;

	
};
}
