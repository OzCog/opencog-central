#include "StdAfx.h"
#include ".\api-constituent.h"

namespace LinkApi
{
	Constituent::Constituent(::Linkage linkage)
	{
		m_node = ::linkage_constituent_tree(linkage);
	}

	Constituent::~Constituent(void)
	{
		::linkage_free_constituent_tree(m_node);
	}
}
