#pragma once



extern "C"
{
  #include "link-includes.h"
}
namespace LinkApi
{
	class Constituent
	{
	public:
		Constituent(::Linkage linkage);
		~Constituent(void);
	private:
		::CNode * m_node;
	
	};
}