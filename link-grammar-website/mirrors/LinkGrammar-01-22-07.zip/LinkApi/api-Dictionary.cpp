#include "StdAfx.h"
#include ".\api-dictionary.h"


namespace LinkApi
{
	Dictionary::Dictionary(void)
	{
		m_dict = ::dictionary_create("4.0.dict", "4.0.knowledge", NULL, "4.0.affix");
	}

	Dictionary::~Dictionary(void)
	{
		::dictionary_delete(m_dict);
	}

	Sentence * 
	Dictionary::CreateSentence(char * input_string)
	{
		return new Sentence(input_string,m_dict);
	}
}