#include "StdAfx.h"
#include ".\api-linkage.h"

namespace LinkApi
{
	Linkage::Linkage(int k,::Sentence sent,::Parse_Options opts)
	{
		m_linkage = ::linkage_create(k,sent,opts);
	}

	Linkage::~Linkage(void)
	{
		::linkage_delete(m_linkage);
	}

	
}